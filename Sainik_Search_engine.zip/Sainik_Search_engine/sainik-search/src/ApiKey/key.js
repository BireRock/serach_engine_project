export const API_KEY = "AIzaSyCuUmGJxaubuN_88C8j3ewoBHG9buUIceA";  
export default API_KEY;