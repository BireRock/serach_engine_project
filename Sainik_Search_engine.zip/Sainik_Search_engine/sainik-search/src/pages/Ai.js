import React from 'react';
import alanBtn from '@alan-ai/alan-sdk-web';
import { useEffect, useState, useCallback } from 'react';

const Commands = {
    SEARCH_QUERY: 'search-query'
}

export default function Ai() {
    const [aiInstance, setAiInstance] = useState()

    const searchQuery = useCallback(() => {
        aiInstance.playText('Searching query')
    }, [aiInstance])

    useEffect(() => {
        window.addEventListener(Commands.SEARCH_QUERY, searchQuery)

        return () => {
            window.removeEventListener(Commands.SEARCH_QUERY, searchQuery)
        }
    }, [aiInstance])
    useEffect(() => {
        if (aiInstance != null) return
        setAiInstance(
            alanBtn({
                top: "60px",
                left: "230px",
                key: '82aa92a0d0307e6287e57d3af8a909ee2e956eca572e1d8b807a3e2338fdd0dc/stage',
                onCommand: ({ command }) => {
                    window.dispatchEvent(new CustomEvent(command))
                }
            })
        )
    }, [])
    return null
}
