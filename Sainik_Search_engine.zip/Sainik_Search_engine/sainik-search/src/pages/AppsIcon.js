import React from 'react'

export default function AppsIcon() {
    return (
        <div>
           <h1>Here We Can Put Our Services</h1> 
        </div>
    )
}
