import React from 'react'

export default function Gmail() {
    return (
        <div>
            <h1>This is Email page</h1>
        </div>
    )
}
