import React from 'react';
import { Link } from 'react-router-dom';
import { Avatar } from '@mui/material';
import AppsIcon from '@mui/icons-material/Apps';
import './Home.css';
import Search from './Search';

export default function Home() {
    return (
        <div className='home'>
            <div className="home-header">
                <div className="home-headerLeft">
                    {/* linking to jayHind Page */}
                    <Link to='/jayHind' style={{ color: 'red', fontWeight: 'bold', marginLeft: '189px' }}>Jay Hind</Link>
                </div>
                <div className="home-headerRight">
                    {/* linking for Email */}
                    <Link to='/gmail'>Email</Link>
                    {/* linking for Images */}
                    <Link to='/images'>Images</Link>
                    <Link to='/appsIcon'><AppsIcon /></Link>
                    
                    <Avatar
                        src="https://cdn.pixabay.com/photo/2016/08/24/17/07/india-1617463__340.png" alt="indian flag logo" />
                </div>
            </div>
            <div className="home-body">
                <img src="https://cdn.pixabay.com/photo/2017/08/15/16/04/indian-flag-2644512_960_720.jpg" alt="search engine Logo" />
                <h1 className="heading">Sainik</h1>
                <h3 className='heading2'>Azadi Ka Amrit Mahotsav</h3>
                <div className="home-inputcontainer">

                    {/* search Page */}
                    <Search />
                </div>
            </div>
        </div>
    )
}
