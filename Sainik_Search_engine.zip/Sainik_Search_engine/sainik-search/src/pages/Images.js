import React from 'react'

export default function Images() {
    return (
        <div>
            <h1>This is Images Page</h1>
        </div>
    )
}
