import React from 'react';
import { Link } from 'react-router-dom';
import './SearchPage.css';
import { useStateValue } from '../services/StateProvider';
import SearchIcon from '@mui/icons-material/Search';
import DescriptionIcon from '@mui/icons-material/Description';
import ImageIcon from '@mui/icons-material/Image';
import LocalOfferIcon from '@mui/icons-material/LocalOffer';
import RoomIcon from '@mui/icons-material/Room';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import response from "../services/response";
import Search from './Search';
import SainikSearch from '../services/SainikSearch';

export default function SearchPage() {

    const [{term='tesla'}, dispatch] = useStateValue();
    // live api call
    const { data } = SainikSearch(term);
    // mock api call
    //  when we use default hard coded search queries
    // const data = response; 

    
    // console.log(data)
    return (
        <div className='searchpage'>
            <div className="searchpage-header">
                <Link to="/">
                    <img className='logo' src="https://cdn.pixabay.com/photo/2017/08/15/16/04/indian-flag-2644512_960_720.jpg" alt="search engine logo" />
                    <h1 className='heading'>sainik</h1>
                    <h3 style={{color:'#d95c1e',fontWeight:'bold'}}>Azadi Ka Amrit Mahotsav</h3>
                </Link>
                <div className="searchpage-body">
                    <Search hideButtons />

                    <div className="searchpage-options">
                        <div className="searchpage-optionleft">
                            <div className="searchpage-option">
                                <SearchIcon />
                                <Link to="/all">All</Link>
                            </div>
                            <div className="searchpage-option">
                                <DescriptionIcon />
                                <Link to="/news">News</Link>
                            </div>

                            <div className="searchpage-option">
                                <ImageIcon />
                                <Link to="/images">Images</Link>
                            </div>
                            <div className="searchpage-option">
                                <LocalOfferIcon />
                                <Link to="/shopping">shopping</Link>
                            </div>
                            <div className="searchpage-option">
                                <RoomIcon />
                                <Link to="/maps">maps</Link>
                            </div>
                            <div className="searchpage-option">
                                <MoreVertIcon />
                                <Link to="/more">more</Link>
                            </div>
                        </div>
                        <div className="searchpage-optionright">
                            <div className="searchpage-option">
                                <Link to="/settings">Settings</Link>
                            </div>
                            <div className="searchpage-option">

                                <Link to="/tools">Tools</Link>
                            </div>
                        </div>
                    </div>

                </div>
             </div> 
            {true && (
                <div className="searchpage-results">
                  <p className='searchpage-resultcount'>
                      About{data?.searchInformation.formattedTotalResults} results 
                      ({data?.searchInformation.formattedSearchTime} seconds) for {term}
                  </p>
                  
                
                  {data?.items.map(item=>(
                      <div className="searchpage-result">
                      <a href={item.link}>
                          {item.pagemap?.cse_image?.length > 0 && item.pagemap?.cse_image[0]?.src &&(
                              <img 
                              className='searchpage-resultimage' 
                              src={item.pagemap?.cse_image[0]?.src} alt='' />
                          )}
                          {item.displayLink}
                      </a>
                        <a className='searchpage-resulttitle' href={item.link}>
                            <h2>{item.title}</h2>
                        </a>
                        <p className='searchpage-resultsnippet'>
                         {item.snippet}
                        </p>
                      </div>
                  ))}
                </div>
            )} 


        </div>
    )
}


