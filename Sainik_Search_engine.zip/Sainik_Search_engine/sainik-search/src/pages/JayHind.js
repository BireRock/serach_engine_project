import React from 'react'

export default function JayHind() {
    return (
        <div>
            <h1>This is jayHind page</h1>
        </div>
    )
}
