import React from "react";
import './App.css';
import Home from './pages/Home';
import {
  BrowserRouter as Router,
  Route,
  Switch,
} from "react-router-dom";
import SearchPage from './pages/SearchPage'
import Gmail from "./pages/Gmail";
import JayHind from "./pages/JayHind";
import Images from "./pages/Images";
import AppsIcon from "./pages/AppsIcon";

function App() {
  return (
    <div className="App">
      <Router>
        <Switch>
          {/* search page */}
          <Route path="/search">
            <SearchPage />
          </Route>

          {/* jayHind page */}
          <Route path="/jayHind">
            <JayHind />
          </Route>

          {/* Gmail page */}
          <Route path="/gmail">
            <Gmail />
          </Route>

          {/* Images Page*/}
          <Route path="/images">
            <Images />
          </Route>

          {/* AppsIcon Page */}
          <Route path="/appsIcon">
            <AppsIcon />
          </Route>

          {/* home page */}
          <Route path="/">
            <Home />
          </Route>
          
        </Switch>
      </Router>

    </div>
  );
}

export default App;
