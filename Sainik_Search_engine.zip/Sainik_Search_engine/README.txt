Jay hind!
here i briefly mentioned all about steps for search engine project

(A) this project developed based on MERN stack.
(B) I have also enclosed demo screenshot of this search engine project inside folder(DemoPic) in file directory.
(B) i have add artificial intelligence feature in this project
    we can use AI feature by using following instructions:-
=> when you open this search engine you get visible an AI based speech Button on TOP left side on the all pages.

=> for demo you can search following terms or talks in your voice by using this button
==> you can say on mic button ==>
   Jay Hind, Hello, Hii, what a soldier think, what does this search engine do, what can i do here, what is isac,
   what is indian army hackathon.

 Now i mentioned following steps to install and run this applicaton:-
(1) i have already build this app and also hosting this app on firebase so its can de directly access on browser by 
    giving this link(https://sainik-search-engine.web.app/).

(2) otherwise this app can be also run localy by getting it's source codes.(npm start)

Note- i have deleted node mudules folder because its consuming more capacity of storage so it can be problem with 
      upload this project on github.
      if needed than you can install node mudules by giving this command(npm install)

Thanks
Jay Hind


